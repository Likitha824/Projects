#ifndef YOURSOLITION_H
#define YOURSOLITION_H

#pragma once

#include "openfhe.h"
#include "ciphertext-ser.h"
#include "cryptocontext-ser.h"
#include "key/key-ser.h"
#include "scheme/ckksrns/ckksrns-ser.h"
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <chrono>

#ifdef _OPENMP
#include <omp.h>
#endif

using namespace lbcrypto;

class CKKSTaskSolver {
private:
    // File paths
    std::string m_CCLocation;
    std::string m_PubKeyLocation;
    std::string m_MultKeyLocation;
    std::string m_RotKeyLocation;
    std::string m_InputLocation;
    std::string m_OutputLocation;

    // Crypto context and keys
    CryptoContext<DCRTPoly> m_cc;
    PublicKey<DCRTPoly> m_PublicKey;
    Ciphertext<DCRTPoly> m_InputC;
    Ciphertext<DCRTPoly> m_OutputC;

    // Model parameters
    std::vector<std::vector<double>> weights1;
    std::vector<std::vector<double>> weights2;
    std::vector<std::vector<double>> weights3;
    
    std::vector<double> bias1;
    std::vector<double> bias2;
    std::vector<double> bias3;

    // Activation parameters
    double alpha;
    double beta;
    double gamma;

    // Scaling parameters
    double y_mean;
    double y_std;

    // Additional parameters
    int num_slots;

    // Precomputed plaintexts
    std::vector<Plaintext> precomputed_first_layer_weights;
    std::vector<Plaintext> precomputed_first_layer_biases;
    std::vector<Plaintext> precomputed_second_layer_weights;
    std::vector<Plaintext> precomputed_activation_coeffs;

    // Track the level for which precomputation has been done.
    int precomp_level;

    // Private methods
    void precomputeWeightsAndBiases(int currentLevel);
    Ciphertext<DCRTPoly> polynomialActivation(
        const Ciphertext<DCRTPoly>& x, 
        const Plaintext& alphaPlain, 
        const Plaintext& betaPlain, 
        const Plaintext& gammaPlain
    );

public:
    // Constructor
    CKKSTaskSolver(std::string ccLocation, std::string pubKeyLocation, 
                   std::string multKeyLocation, std::string rotKeyLocation,
                   std::string inputLocation, std::string outputLocation);

    // Initialization methods
    void initCC();
    void loadModelWeights();

    // Main inference method
    void eval();

    // Output serialization
    void serializeOutput();
};

#endif // YOURSOLITION_H
