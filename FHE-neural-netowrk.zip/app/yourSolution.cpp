#include "yourSolution.h"

// Constructor implementation
CKKSTaskSolver::CKKSTaskSolver(std::string ccLocation, std::string pubKeyLocation, 
                               std::string multKeyLocation, std::string rotKeyLocation,
                               std::string inputLocation, std::string outputLocation) : 
    m_CCLocation(ccLocation),
    m_PubKeyLocation(pubKeyLocation),
    m_MultKeyLocation(multKeyLocation), 
    m_RotKeyLocation(rotKeyLocation),
    m_InputLocation(inputLocation),
    m_OutputLocation(outputLocation),
    precomp_level(-1) // initialize precomputation flag
{
    // Initialize the crypto context and load input
    initCC();
    loadModelWeights();
}

// Initialize Crypto Context
void CKKSTaskSolver::initCC() {
    std::cout << "Initializing crypto context..." << std::endl;
    
    if (!Serial::DeserializeFromFile(m_CCLocation, m_cc, SerType::BINARY)) {
        std::cerr << "Could not deserialize cryptocontext file" << std::endl;
        exit(1);
    }
    
    num_slots = m_cc->GetEncodingParams()->GetBatchSize();
    std::cout << "Using " << num_slots << " slots for encoding" << std::endl;
    
    try {
        if (!Serial::DeserializeFromFile(m_PubKeyLocation, m_PublicKey, SerType::BINARY)) {
            throw std::runtime_error("Could not deserialize public key");
        }
        
        std::ifstream multKeyIStream(m_MultKeyLocation, std::ios::in | std::ios::binary);
        if (!multKeyIStream.is_open() || 
            !m_cc->DeserializeEvalMultKey(multKeyIStream, SerType::BINARY)) {
            throw std::runtime_error("Could not deserialize multiplication key");
        }
        
        std::ifstream rotKeyIStream(m_RotKeyLocation, std::ios::in | std::ios::binary);
        if (!rotKeyIStream.is_open() || 
            !m_cc->DeserializeEvalAutomorphismKey(rotKeyIStream, SerType::BINARY)) {
            throw std::runtime_error("Could not deserialize rotation key");
        }
        
        if (!Serial::DeserializeFromFile(m_InputLocation, m_InputC, SerType::BINARY)) {
            throw std::runtime_error("Could not deserialize Input ciphertext");
        }
    } catch (const std::exception& e) {
        std::cerr << "Initialization Error: " << e.what() << std::endl;
        exit(1);
    }
    
    std::cout << "Crypto context initialized successfully" << std::endl;
}

// Load Model Weights
void CKKSTaskSolver::loadModelWeights() {
    try {
        std::cout << "Loading model weights from binary file..." << std::endl;
        
        // Model structure parameters (hardcoded)
        int input_dim = 13;
        int hidden1_dim = 8;
        int hidden2_dim = 4;
        int output_dim = 1;
        
        std::ifstream weightsFile("model_weights.bin", std::ios::binary);
        if (!weightsFile.is_open()) {
            weightsFile.open("model_weights/model_weights.bin", std::ios::binary);
            if (!weightsFile.is_open()) {
                throw std::runtime_error("Could not open model weights file");
            }
        }
        
        weightsFile.seekg(0, std::ios::end);
        size_t fileSize = weightsFile.tellg();
        weightsFile.seekg(0, std::ios::beg);
        
        std::vector<float> buffer(fileSize / sizeof(float));
        weightsFile.read(reinterpret_cast<char*>(buffer.data()), fileSize);
        
        // Resize containers
        weights1.resize(input_dim, std::vector<double>(hidden1_dim));
        bias1.resize(hidden1_dim);
        weights2.resize(hidden1_dim, std::vector<double>(hidden2_dim));
        bias2.resize(hidden2_dim);
        weights3.resize(hidden2_dim, std::vector<double>(output_dim));
        bias3.resize(output_dim);
        
        size_t pos = 0;
        // First layer weights
        for (int j = 0; j < hidden1_dim; j++) {
            for (int i = 0; i < input_dim; i++) {
                weights1[i][j] = buffer[pos++];
            }
        }
        // First layer biases
        for (int i = 0; i < hidden1_dim; i++) {
            bias1[i] = buffer[pos++];
        }
        // Second layer weights
        for (int j = 0; j < hidden2_dim; j++) {
            for (int i = 0; i < hidden1_dim; i++) {
                weights2[i][j] = buffer[pos++];
            }
        }
        // Second layer biases
        for (int i = 0; i < hidden2_dim; i++) {
            bias2[i] = buffer[pos++];
        }
        // Output layer weights
        for (int j = 0; j < output_dim; j++) {
            for (int i = 0; i < hidden2_dim; i++) {
                weights3[i][j] = buffer[pos++];
            }
        }
        // Output layer biases
        for (int i = 0; i < output_dim; i++) {
            bias3[i] = buffer[pos++];
        }
        // Load polynomial activation parameters
        alpha = buffer[pos++];
        beta  = buffer[pos++];
        gamma = buffer[pos++];
        
        // Scaling parameters (hardcoded)
        y_mean = 207630.16511165493;
        y_std  = 116556.17916466035;
        
    } catch (const std::exception& e) {
        std::cerr << "Weight Loading Error: " << e.what() << std::endl;
        exit(1);
    }
}

// Precompute Weights and Biases (optimized to run only once per level)
void CKKSTaskSolver::precomputeWeightsAndBiases(int currentLevel) {
    if (precomp_level == currentLevel) {
        // Already computed for this level
        return;
    }
    // Clear previous values
    precomputed_first_layer_weights.clear();
    precomputed_first_layer_biases.clear();
    precomputed_second_layer_weights.clear();
    precomputed_activation_coeffs.clear();

    // Precompute activation coefficients (replicated across slots)
    std::vector<double> alphaVec(num_slots, alpha);
    std::vector<double> betaVec(num_slots, beta);
    std::vector<double> gammaVec(num_slots, gamma);

    precomputed_activation_coeffs = {
        m_cc->MakeCKKSPackedPlaintext(alphaVec, 1, currentLevel),
        m_cc->MakeCKKSPackedPlaintext(betaVec, 1, currentLevel),
        m_cc->MakeCKKSPackedPlaintext(gammaVec, 1, currentLevel)
    };

    int input_dim = 13;
    int hidden1_size = 8;
    int hidden2_size = 4;

    // Precompute first layer weights and biases
    for (int h = 0; h < hidden1_size; h++) {
        std::vector<double> weightVec(input_dim, 0.0);
        for (int i = 0; i < input_dim; i++) {
            weightVec[i] = weights1[i][h];
        }
        precomputed_first_layer_weights.push_back(
            m_cc->MakeCKKSPackedPlaintext(weightVec, 1, currentLevel)
        );

        std::vector<double> biasVec(num_slots, bias1[h]);
        precomputed_first_layer_biases.push_back(
            m_cc->MakeCKKSPackedPlaintext(biasVec, 1, currentLevel)
        );
    }

    // Precompute second layer weights (fused with output layer weights)
    for (int i = 0; i < hidden1_size; i++) {
        for (int j = 0; j < hidden2_size; j++) {
            std::vector<double> weightVec(num_slots, weights2[i][j] * weights3[j][0]);
            precomputed_second_layer_weights.push_back(
                m_cc->MakeCKKSPackedPlaintext(weightVec, 1, currentLevel)
            );
        }
    }

    precomp_level = currentLevel; // mark precomputation as done for this level
}

// Polynomial Activation (quadratic)
Ciphertext<DCRTPoly> CKKSTaskSolver::polynomialActivation(
    const Ciphertext<DCRTPoly>& x, 
    const Plaintext& alphaPlain, 
    const Plaintext& betaPlain, 
    const Plaintext& gammaPlain
) {
    auto linear = m_cc->EvalMult(x, betaPlain);
    auto result = m_cc->EvalAdd(linear, alphaPlain);

    auto squared = m_cc->EvalMult(x, x);
    auto quadratic = m_cc->EvalMult(squared, gammaPlain);
    result = m_cc->EvalAdd(result, quadratic);

    return result;
}

// Main Inference Method (optimized)
void CKKSTaskSolver::eval() {
    auto start = std::chrono::high_resolution_clock::now();

    int currentLevel = m_InputC->GetLevel();
    int input_dim = 13;
    int hidden1_size = 8;
    int hidden2_size = 4;
    
    // Precompute plaintexts if needed (only once per level)
    precomputeWeightsAndBiases(currentLevel);

    // First layer computation: process each neuron independently.
    std::vector<Ciphertext<DCRTPoly>> firstLayerOutputs(hidden1_size);

    #ifdef _OPENMP
    #pragma omp parallel for
    #endif
    for (int h = 0; h < hidden1_size; h++) {
        auto weighted = m_cc->EvalMult(m_InputC, precomputed_first_layer_weights[h]);
        auto summed = m_cc->EvalSum(weighted, input_dim);
        auto preActivation = m_cc->EvalAdd(summed, precomputed_first_layer_biases[h]);
        firstLayerOutputs[h] = polynomialActivation(
            preActivation, 
            precomputed_activation_coeffs[0],
            precomputed_activation_coeffs[1],
            precomputed_activation_coeffs[2]
        );
    }
    
    // Second layer computation: parallelize evaluation of weighted paths.
    int totalPaths = hidden1_size * hidden2_size;
    std::vector<Ciphertext<DCRTPoly>> partialOutputs(totalPaths);
    
    #ifdef _OPENMP
    #pragma omp parallel for collapse(2)
    #endif
    for (int i = 0; i < hidden1_size; i++) {
        for (int j = 0; j < hidden2_size; j++) {
            int idx = i * hidden2_size + j;
            partialOutputs[idx] = m_cc->EvalMult(firstLayerOutputs[i], precomputed_second_layer_weights[idx]);
        }
    }
    
    // Combine all partial outputs
    Ciphertext<DCRTPoly> finalOutput = partialOutputs[0];
    for (int idx = 1; idx < totalPaths; idx++) {
        finalOutput = m_cc->EvalAdd(finalOutput, partialOutputs[idx]);
    }
    
    // Compute combined bias from second and output layers.
    double combinedBias = 0.0;
    for (int j = 0; j < hidden2_size; j++) {
        combinedBias += bias2[j] * weights3[j][0];
    }
    combinedBias += bias3[0];
    
    std::vector<double> biasVec(num_slots, combinedBias);
    Plaintext biasPlain = m_cc->MakeCKKSPackedPlaintext(biasVec, 1, finalOutput->GetLevel());
    finalOutput = m_cc->EvalAdd(finalOutput, biasPlain);
    
    // Scaling: fuse scaling operations.
    std::vector<double> stdVec(num_slots, y_std);
    std::vector<double> meanVec(num_slots, y_mean);
    Plaintext stdPlain = m_cc->MakeCKKSPackedPlaintext(stdVec, 1, finalOutput->GetLevel());
    Plaintext meanPlain = m_cc->MakeCKKSPackedPlaintext(meanVec, 1, finalOutput->GetLevel());
    
    m_OutputC = m_cc->EvalAdd(m_cc->EvalMult(finalOutput, stdPlain), meanPlain);

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> diff = end - start;
    std::cout << "Inference Time: " << diff.count() << " seconds" << std::endl;
}

// Serialize output method
void CKKSTaskSolver::serializeOutput() {
    if (!Serial::SerializeToFile(m_OutputLocation, m_OutputC, SerType::BINARY)) {
        std::cerr << "Failed to serialize the output to " << m_OutputLocation << std::endl;
        exit(1);
    }
    std::cout << "Result saved to " << m_OutputLocation << std::endl;
}
